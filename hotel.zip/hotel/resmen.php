<?php
	include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home(HOTEL MANAGEMENT)</title>
	<link rel="stylesheet" type="text/css" href="css/style-res.css">
</head>
<body>
	<div id="full">
	<div id="front" style="background-image: url('img/rback.jpg');height: 1000px;">
		<div id="header">
			<div id="logo">
				<ul><h1 style="font-family:'Times New Roman'">_RESTAURANT MENU_</h1><ul>
			</div>
			<div id="nav"><br>
				<ul>
					<li><a href="index.php"><font size="4">Home</font></a></li>
					<li><a href="bookings.php"><font size="4">Bookings</font></a></li>
					<li><a href="resmen.php"><font size="4">Restaurant Menu</font></a></li>
					<li><a href="contact.php"><font size="4">Contact Us</font></a></li>
					<li><a href="admin.php"><font size="4">Staff Login</font></a></li>
				</ul>
			</div>
		</div>
		<center>
		<div id="banner"><br><br><br><br><br>
			<div style="background:rgba(255, 255,255,0.6);width:80%;">
			<div id="form">
				<form action="resmen.php" method="post">
			<table style="color: black;">
                    <tr>
					<td><font size="4">Item Name</font></td>
					<td>
						<select name="item">
						<option>--select--</option>
						<option>Pancakes</option>
						<option>Spicy Noodles</option>
						<option>Cakes</option>
						<option>Biryani</option>
						<option>Rice & Curry</option>
						<option>French Fries</option>
						<option>Donuts</option>
						<option>Cold Coffee</option>
                        <option>Tea</option>
						<option>Green Tea</option>
						</select>
					</td>
                    </tr></br>
				<tr>
					<td><font size="4">Quantity</font></td>
					<td><select name="quantity">
						<option>--select--</option>
						<option>1</option>
						<option>2</option>
						<option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
					</select></td>
				</tr>
                                
                                <tr>
					<td><font size="4">Room Number</font></td>
					<td><input type="text" name="number" placeholder="Enter Room Number" title="RoomNumber"></td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="submit" name="sub1" value="Place Order" style="width: 150px ;height:40px;border-radius: 30px;">
					</td>
				</tr>
                        </table>
						</form>
				<?php
				if(isset($_POST['sub1']))
				{
					$item=$_POST['item'];
					$qty=$_POST['quantity'];
					$room_num=$_POST['number'];
					if(mysqli_query($a, "insert into restmenu(restitem, qty, room_num) values('$item','$qty','$room_num')"))
					{
						echo "YOUR ORDER HAS BEEN PLACED!!";
					}
					else
					{
						echo "ORDER FAILED :(";
					}
				}
				?>
				</center>
				</div>	
			</div>
			</div>	
	</div>
	</div>	
	</body>
	</html>