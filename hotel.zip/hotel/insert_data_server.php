<?php
	
		$name=$_POST['name'];
		$idno=$_POST['idno'];
		$address=$_POST['address'];
		$city=$_POST['city'];
		$state=$_POST['state'];
		$email=$_POST['email'];
		$destination=$_POST['destination'];
		$checkin=$_POST['ci'];
		$checkout=$_POST['co'];
		$num_ppl=$_POST['people'];
		$num_room=$_POST['room'];
		$room_type=$_POST['roomtype'];
		$connection=mysqli_connect('localhost','root','','hotel management');
		if(!$connection)
			die("Connection failed".mysqli_connect_error());
		$query="insert into bookings values('$name',$adhaar,'$address','$city','$state','$email','$destination','$checkin','$checkout',$num_ppl,$num_rooms,'$room_type')";
		if(mysqli_query($connection,$query))
			echo "data entered successfully.";
		else
			echo "failed to enter data.";
?>