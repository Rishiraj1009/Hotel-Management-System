<!DOCTYPE html>
<html>
<head>
	<title>Contact Us(HOTEL MANAGEMENT)</title>
	<link rel="stylesheet" type="text/css" href="css/style-con.css">
</head>
<body>
	<div id="contact">
	<div id="bg" style="background-image: url('img/conback.jpg');height: 1000px;">
		<div id="header">
		<div id="logo">
			<h1>__CONTACT US__</h1>
		</div>
			<div id="nav"><br>
				<ul>
					<li><a href="index.php"><font size="4">Home</font></a></li>
					<li><a href="bookings.php"><font size="4">Bookings</font></a></li>
					<li><a href="resmen.php"><font size="4">Restaurant Menu</font></a></li>
					<li><a href="contact.php"><font size="4">Contact Us</font></a></li>
					<li><a href="admin.php"><font size="4">Staff Login</font></a></li>
				</ul>
			</div>
		</div>
		<div id="sub">
			<ul>
				<li><img src="img/mail.png" width="50px"><a href = "mailto: hotel.managementa7@gmail.com">Send Email</a></li>
				<li><img src="img/phone.png" width="50px"><a href="tel:7000000007">Call Us</a></li>
			</ul>
		</div>
	</div>
	</div>
</body>