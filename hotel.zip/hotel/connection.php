<?php
$a=mysqli_connect('localhost','root','','hotel management');
?>