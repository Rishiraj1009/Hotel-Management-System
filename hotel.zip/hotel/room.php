<?php
	include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bookings</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-image: url('img/i1.jpeg'); height: 1200px;">
		<div id="header">
			<div id="logo">
				<u1><h1 style="font-family:'Times New Roman'">Hotel Management System</h1></u1>
			</div>
			<div id="nav">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Bookings</a></li>
					<li><a href="#">Restaurant Menu</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Staff Login</a></li>
				</ul>
			</div>
		</div>
		<div id="banner">
			<div id="form">
                        	<form action="bookings.php" method="post">
			<table style="color: black;">
                                <tr>
					<td>Name</td>
					<td><input type="text" name="name" placeholder="Enter Name" title="Name"></td>
                                </tr>
                                <tr>
					<td>Adhaar no.</td>
					<td><input type="text" name="idno" placeholder="Enter adhaar no." title="ID"></td>
				</tr>
				<tr>
					<td>Address</td>
					<td><input type="text" name="address" placeholder="Enter Address" title="Address"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><select name="city">
						<option>--select--</option>
						<option>Mumbai</option>
						<option>Delhi</option>
						<option>Bengrulu</option>
                                                <option>Chennai</option>
                                                <option>Kolkata</option>
                                                <option>Lucknow</option>
					</select></td>
				</tr>
                                <tr>
					<td>State</td>
					<td><select name="state">
						<option>--select--</option>
						<option>Maharashtra</option>
						<option>Delhi</option>
						<option>Andhra Pradesh</option>
                                                <option>Tamil Nadu</option>
                                                <option>West Bengal</option>
                                                <option>Uttar Pradesh</option>
					</select></td>
				</tr>
				<tr>
					<td>Enter E-mail</td>
					<td><input type="text" name="email" placeholder="Enter E-mail" title="E-mail"></td>
				</tr>
                                <tr>
					<td>Destination</td>
					<td><input type="text" name="destination" placeholder="Enter your destination" title="Destination"></td>
				</tr>
                                <tr>
				        <th width="20%" height="50px">Check In Date</th>
                                        <td width="20%" height="50px"><center><input type="text" name="ci" placeholder="dd/mmm/yyyy"></center></td>
				        <th width="20%" height="50px">Check Out Date</th>
                                        <td width="20%" height="50px"><center><input type="text" name="co" placeholder="dd/mm/yyyy"></center></td>
                                </tr>
				<tr>
					<td>Number of People</td>
					<td><input type="text" name="people" placeholder="Enter number of people" title="People"></td>
				</tr>
                                <tr>
					<td>Number of Rooms</td>
					<td><input type="text" name="room" placeholder="Enter number of rooms" title="Room"></td>
				</tr>
                                </tr>
                                        <td>Type of Room</td>
                                        <td><select name="roomtype">
						<option>--select--</option>
						<option>Single</option>
						<option>Double</option>
						<option>Twin</option>
                                                <option>Connecting</option>
                                                <option>Suite</option>
					</select></td>
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
                        </table>
                </form>
				<?php
				if(isset($_POST['submit']))
				{
					}
				}
				?>
		    </div>
	    </div>
	    </div>
	</div>
</body>
</html>