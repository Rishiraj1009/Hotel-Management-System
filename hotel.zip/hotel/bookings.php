<?php
	include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bookings</title>
	<link rel="stylesheet" type="text/css" href="css/style-book.css">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-image: url('img/i3.jpg'); height: 1200px;">
		<div id="header">
			<div id="logo">
				<u1><h1 style="font-family:'Times New Roman'">_ROOM BOOKING PAGE_</h1></u1>
			</div>
			<div id="nav"><br>
				<ul>
					<li><a href="index.php"><font size="4">Home</font></a></li>
					<li><a href="bookings.php"><font size="4">Bookings</font></a></li>
					<li><a href="resmen.php"><font size="4">Restaurant Menu</font></a></li>
					<li><a href="contact.php"><font size="4">Contact Us</font></a></li>
					<li><a href="admin.php"><font size="4">Staff Login</font></a></li>
				</ul>
			</div>
		</div>
		<center>
		<div id="banner">
			<div id="form">
			<div style="background:rgba(255, 255,255,0.5);width:90%;">
                        	<form action="bookings.php" method="post">
			<table style="color: black;">
                                <tr>
					<td><font size="4">Name</font></td>
					<td><input type="text" name="name" placeholder="Enter Name" title="Name"></td>
                                </tr>
                                <tr>
					<td><font size="4">Adhaar no.</font></td>
					<td><input type="text" name="idno" placeholder="Enter adhaar no." title="ID"></td>
				</tr>
				<tr>
					<td><font size="4">Address</font></td>
					<td><input type="text" name="address" placeholder="Enter Address" title="Address"></td>
				</tr>
				<tr>
					<td><font size="4">City</font></td>
					<td><input type="text" name="city" placeholder="Enter City" title="City"></td>
				</tr>
								<tr>
					<td><font size="4">State</font></td>
					<td><input type="text" name="state" placeholder="Enter State" title="State"></td>
				</tr>
				<tr>
					<td><font size="4">Enter E-mail</font></td>
					<td><input type="text" name="email" placeholder="Enter E-mail" title="E-mail"></td>
				</tr>
				<tr>
					<td><font size="4">Phone number</font></td>
					<td><input type="text" name="phoneno" placeholder="Enter Phone" title="Phone no."></td>
				</tr>
                <tr>
					<td><font size="4">Destination</font></td>
					<td><input type="text" name="destination" placeholder="Enter your destination" title="Destination"></td>
				</tr>
				<tr>
					<td><font size="4">Number of People</font></td>
					<td><input type="text" name="people" placeholder="Enter number of people" title="People"></td>
				</tr>
                                <tr>
					<td><font size="4">Number of Rooms</font></td>
					<td><input type="text" name="room" placeholder="Enter number of rooms" title="Room"></td>
				</tr>
                                <tr>
					<td><font size="4">Check In Date</font></td>
					<td><input type="date" name="ci" placeholder="dd/mm/yyyy"></td>
				</tr>
                                <tr>
					<td><font size="4">Check Out Date</font></td>
					<td><input type="date" name="co" placeholder="dd/mm/yyyy"></td>
				</tr>
                                </tr>
                                        <td><font size="4">Type of Room</font></td>
                                        <td><select name="roomtype">
						<option>--select--</option>
						<option>Single</option>
						<option>Double</option>
						<option>Twin</option>
						<option>Connecting</option>
						<option>Suite</option>
					</select></td>
				<tr>
					<td colspan="2">
						<input type="submit" name="submit" value="Book" style="width: 150px ;height:40px;border-radius: 30px;">
					</td>
				</tr>
                        </table>
                </form>
				<?php
				if(isset($_POST['submit']))
				{
					$name=$_POST['name'];
					$idno=$_POST['idno'];
					$address=$_POST['address'];
					$city=$_POST['city'];
					$state=$_POST['state'];
					$email=$_POST['email'];
					$phoneno=$_POST['phoneno'];
					$destination=$_POST['destination'];
					$ci=$_POST['ci'];
					$co=$_POST['co'];
					$people=$_POST['people'];
					$room=$_POST['room'];
					$roomtype=$_POST['roomtype'];
					if(mysqli_query($a, "insert into bookings(name, adhaar, address, city, state, email, phoneno, 
					destination, checkin, checkout, num_ppl, num_rooms, room_type) values('$name','$idno','$address',
					'$city','$state','$email','$phoneno', '$destination','$ci','$co','$people','$room','$roomtype')"))
					{
						echo "<p> <font color=black>BOOKING SUCCESSFUL!!</font> </p>";
					}
					else
					{
						echo "BOOKING UNSUCCESSFUL";
					}
				}
				?>
				</center>
		    </div>
			</div>
	    </div>
	    </div>
	</div>
</body>
</html>