<?php
	include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="css/style-admin.css">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-image: url('img/back1.png'); height: 100%;">
		<div id="header">
			<div id="logo">
				<u1><h1 style="font-family:'Times New Roman'">_STAFF LOGIN_</h1></u1>
			</div>
			<div id="nav"><br>
				<ul>
					<li><a href="index.php"><font size="4">Home</font></a></li>
					<li><a href="bookings.php"><font size="4">Bookings</font></a></li>
					<li><a href="resmen.php"><font size="4">Restaurant Menu</font></a></li>
					<li><a href="contact.php"><font size="4">Contact Us</font></a></li>
					<li><a href="admin.php"><font size="4">Staff Login</font></a></li>
				</ul>
			</div>
		</div>
		<center>
		<div id="banner"><br><br><br><br><br>
			<center>
				<div style="background:rgba(255, 255,255,0.6);width:80%;">
				<form action="" method="post" >
					<table>
						<tr>
							<td width="50%" height="50px"><font size="4">Staff Id.</font></td>
							<td width="50%" height="50px"><input type="text" name="un" placeholder="Enter Staff ID" title="Enter Staff ID"></td>
						</tr>
						<tr>
							<td width="50%" height="50px"><font size="4">Password</form></td>
							<td width="50%" height="50px"><input type="password" name="ps" placeholder="Enter Password" title="Enter Password"></td>
						</tr>
						<tr>
							<td colspan="2">
								<ul><input type="submit" name="sub" value="Login" style="width: 150px ;height:40px;border-radius: 30px;"></ul>
							</td>
						</tr>
					</table>
					</form>
					<?php
					if(isset($_POST['sub']))
					{
						$staffid=$_POST['un'];
						$password=$_POST['ps'];
						$q1="select * from admin";
						$run=mysqli_query($a,$q1);
						$row=mysqli_fetch_array($run);
						$u=$row['staffid'];
						$p=$row['password'];
						if($staffid==$u && $password==$p)
						{
							header("Location: welcomeadmin.php");
						}
						else
						{
							echo "Wrong staffid/password";
						}	
					}
					?>					
				</div>
			</center>
		</div>
	</center>
     </div>
	</div>
</body>
</html>