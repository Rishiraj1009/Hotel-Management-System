<?php
	include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="CSS/style-1.css">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-image: url('img/back1.png'); height: 1200px;">
		<div id="header">
			<div id="logo">
				<u1><h1 style="font-family:'Times New Roman'">_CUSTOMER INFO_</h1></u1>
			</div>
			<div id="nav"><br>
				<ul>
					<li><a href="index.php"><font size="4">Home</font></a></li>
					<li><a href="bookings.php"><font size="4">Bookings</font></a></li>
					<li><a href="resmen.php"><font size="4">Restaurant Menu</font></a></li>
					<li><a href="contact.php"><font size="4">Contact Us</font></a></li>
					<li><a href="admin.php"><font size="4">Staff Login</font></a></li>
				</ul>
			</div>
		</div>
        <center>
        <div id="banner1"><br><br><br><br><br>            
            
            <div style="background:rgba(255, 255,255,0.7);width:100%;display:inline-block;border-spacing: 0 15px">
                <h1 style="color:rgb(9, 75, 9);text-align: center;">Customer Info</h1>
            <table>
                <tr>
                    <th width="10%" height="50px" >Name</th>
                    <th width="10%" height="50px" >Adhaar No.</th>
					<th width="10%" height="50px" >Address</th>
                    <th width="10%" height="50px" >City</th>
                    <th width="10%" height="50px" >State</th>
					<th width="10%" height="50px" >Email Id</th>
					<th width="10%" height="50px" >Phone no.</th>
					<th width="10%" height="50px" >Destination</th>
                    <th width="10%" height="50px" >Check in date</th>
                    <th width="10%" height="50px" >Check out date</th>
                    <th width="10%" height="50px" >Number of people</th>
					<th width="10%" height="50px" >Type of Room</th>
					<th width="10%" height="50px" >Number of Rooms</th>
                </tr>
				<?php
				$q1="select * from bookings";
				$run=mysqli_query($a, $q1);
				while($row=mysqli_fetch_assoc($run))
				{
					$name=$row['name'];
					$idno=$row['adhaar'];
					$address=$row['address'];
					$city=$row['city'];
					$state=$row['state'];
					$email=$row['email'];
					$phoneno=$row['phoneno'];
					$destination=$row['destination'];
					$ci=$row['checkin'];
					$co=$row['checkout'];
					$people=$row['num_ppl'];
					$room_type=$row['room_type'];
					$num_rooms=$row['num_rooms'];
				?>
				<tr>
                    <td width="10%" height="50px" ><center><?php echo $name; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $idno; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $address; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $city; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $state; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $email; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $phoneno; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $destination; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $ci; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $co; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $people; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $room_type; ?></center></td>
					<td width="10%" height="50px" ><center><?php echo $num_rooms; ?></center></td>
				</tr>
				<?php 
				};
				?>
					

            </table>
            </div>
        </div>
        </center>
        </div>
    </div>
</body>

        